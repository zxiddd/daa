#include <stdio.h> 
#include <stdbool.h> 
 
#define MAX 20 
 
void printSolution(int path[], int n) { 
    for (int i = 0; i < n; i++) 
        printf(" %d ", path[i]); 
    printf(" %d\n", path[0]); 
} 
 
bool isSafe(int v, int graph[MAX][MAX], int path[], int pos) { 
    if (graph[path[pos - 1]][v] == 0) 
        return false; 
 
    for (int i = 0; i < pos; i++) 
        if (path[i] == v) 
            return false; 
 
    return true; 
} 
 
void hamCycleUtil(int graph[MAX][MAX], int path[], int pos, int n) { 
    if (pos == n) { 
        if (graph[path[pos - 1]][path[0]] == 1) { 
            printSolution(path, n); 
        } 
        return; 
    } 
 
    for (int v = 1; v < n; v++) { 
        if (isSafe(v, graph, path, pos)) { 
            path[pos] = v; 
            hamCycleUtil(graph, path, pos + 1, n); 
            path[pos] = -1; 
        } 
    } 
} 
 
void hamCycle(int graph[MAX][MAX], int n) { 
    int path[MAX]; 
    for (int i = 0; i < n; i++) 
        path[i] = -1; 
 
    path[0] = 0; 

 
    hamCycleUtil(graph, path, 1, n); 
} 
 
int main() { 
    int n; 
    int graph[MAX][MAX]; 
 
    printf("Enter the number of vertices: "); 
    scanf("%d", &n); 
 
    printf("Enter the adjacency matrix of the graph:\n"); 
    for (int i = 0; i < n; i++) 
        for (int j = 0; j < n; j++) 
            scanf("%d", &graph[i][j]); 
 
    printf("Hamiltonian Cycles:\n"); 
    hamCycle(graph, n); 
    return 0; 
} 