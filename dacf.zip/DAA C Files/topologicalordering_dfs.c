#include <stdio.h> 
#include <stdlib.h> 
 
#define MAX_VERTICES 100 
 
struct Node { 
    int vertex; 
    struct Node* next; 
}; 
 
struct Graph { 
    int numVertices; 
    struct Node** adjLists; 
    int* visited; 
}; 
 
struct Node* createNode(int v) { 
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node)); 
    newNode->vertex = v; 
    newNode->next = NULL; 
    return newNode; 
} 
 
struct Graph* createGraph(int vertices) { 
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph)); 
    graph->numVertices = vertices; 
 
    graph->adjLists = (struct Node**)malloc(vertices * sizeof(struct Node*)); 
    graph->visited = (int*)malloc(vertices * sizeof(int)); 
 
    for (int i = 0; i < vertices; i++) { 
        graph->adjLists[i] = NULL; 
        graph->visited[i] = 0; 
    } 
    return graph; 
} 
 
void addEdge(struct Graph* graph, int src, int dest) { 
    struct Node* newNode = createNode(dest); 
    newNode->next = graph->adjLists[src]; 
    graph->adjLists[src] = newNode; 
} 
 
void topologicalSortDFS(struct Graph* graph, int v, int visited[], struct Node** stack) { 
    visited[v] = 1; 
 
 
    struct Node* adjList = graph->adjLists[v]; 
    while (adjList != NULL) { 
        int connectedVertex = adjList->vertex; 
        if (!visited[connectedVertex]) { 
            topologicalSortDFS(graph, connectedVertex, visited, stack); 
        } 
        adjList = adjList->next; 
    } 
 
    struct Node* newNode = createNode(v); 
    newNode->next = *stack; 
    *stack = newNode; 
} 
 
void printStack(struct Node* stack) { 
    while (stack != NULL) { 
        printf("%d ", stack->vertex); 
        stack = stack->next; 
    } 
    printf("\n"); 
} 
 
void topologicalSortUsingDFS(struct Graph* graph) { 
    struct Node* stack = NULL; 
    int* visited = (int*)malloc(graph->numVertices * sizeof(int)); 
 
    for (int i = 0; i < graph->numVertices; i++) { 
        visited[i] = 0; 
    } 
 
    for (int i = 0; i < graph->numVertices; i++) { 
        if (visited[i] == 0) { 
            topologicalSortDFS(graph, i, visited, &stack); 
        } 
    } 
 
    printf("Topological Sorting using DFS: "); 
    printStack(stack); 
} 
 
int main() { 
    int vertices, edges, src, dest; 
 
    printf("Enter the number of vertices: "); 
    scanf("%d", &vertices); 
 
    struct Graph* graph = createGraph(vertices); 
 
 
    printf("Enter the number of edges: "); 
    scanf("%d", &edges); 
 
    for (int i = 0; i < edges; i++) { 
        printf("Enter edge %d (source destination): ", i + 1); 
        scanf("%d %d", &src, &dest); 
        addEdge(graph, src, dest); 
    } 
 
    topologicalSortUsingDFS(graph); 
 
    return 0; 
}