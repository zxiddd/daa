#include <stdio.h> 
#include <limits.h> 
 
#define MAX_CITIES 10 
 
int n;  
int dist[MAX_CITIES][MAX_CITIES];  
int visited[MAX_CITIES];  
int bestPath[MAX_CITIES];  
int minCost = INT_MAX;  
 
void tsp(int currentCity, int visitedCount, int cost, int path[]) { 
     
    if (visitedCount == n) { 
         
        cost += dist[currentCity][0]; 
         
        if (cost < minCost) { 
            minCost = cost; 
            for (int i = 0; i < n; i++) { 
                bestPath[i] = path[i]; 
            } 
        } 
        return; 
    } 
     
    for (int nextCity = 0; nextCity < n; nextCity++) { 
        if (!visited[nextCity]) { 
             
            visited[nextCity] = 1; 
             
            path[visitedCount] = nextCity; 
            int newCost = cost + dist[currentCity][nextCity]; 
             
            if (newCost < minCost) { 
                tsp(nextCity, visitedCount + 1, newCost, path); 
            } 
             
            visited[nextCity] = 0; 
        } 
    } 
} 
 
void printPath() { 
    printf("Path: "); 
    for (int i = 0; i < n; i++) { 

 
        printf("%d -> ", bestPath[i] + 1);  
    } 
    printf("1\n");  
} 
 
int main() { 
    printf("Enter the number of cities: "); 
    scanf("%d", &n); 
     
    printf("Enter the distance matrix (%d x %d):\n", n, n); 
    for (int i = 0; i < n; i++) { 
        for (int j = 0; j < n; j++) { 
            scanf("%d", &dist[i][j]); 
        } 
    } 
     
    for (int i = 0; i < n; i++) { 
        visited[i] = 0; 
    } 
     
    visited[0] = 1; 
    int path[MAX_CITIES]; 
    path[0] = 0;  
     
    tsp(0, 1, 0, path); 
     
    printf("Minimum cost of visiting all cities: %d\n", minCost); 
    printPath(); 
     
    return 0; 
}